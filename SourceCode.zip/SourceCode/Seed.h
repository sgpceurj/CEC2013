/*
 *  Seed.h
 *  MallowsEDA
 *
 *  Created by Josu Ceberio Uribe on 2/15/12.
 *  Copyright 2012 University of the Basque Country. All rights reserved.
 *
 */

void seed(void);
