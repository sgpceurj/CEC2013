/*
 *  PBP.cpp
 *  MixtureMallowsEDA
 *
 *  Created by Josu Ceberio Uribe on 6/25/12.
 *  Copyright 2012 University of the Basque Country. All rights reserved.
 *
 */

#include "PBP.h"

/*
 * The constructor.
 */
PBP::PBP()
{
	
}

/*
 * The destructor. It frees the memory allocated at the construction of the kendall model.
 */
PBP::~PBP()
{
	//cout<<"Deleting distance model"<<endl;
}
